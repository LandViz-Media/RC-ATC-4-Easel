# NC Thumbnail Prototype v0.1.6

Standalone prototype for the RC-ATC-4-Easel project.

## Purpose

This prototype tests whether browser-side JavaScript can read Easel/MASSO `.nc` files and render a useful 2D top-down thumbnail of the XY toolpath.

It is intentionally separate from the composer so that experimenting with visualization cannot affect the known-good G-code generation.

## Current capabilities

- Load multiple `.nc`, `.gcode`, or `.txt` files.
- Drag and drop files.
- Parse `G0`, `G1`, `G2`, and `G3` XY motion.
- Handle `G20` inch and `G21` metric units.
- Draw cutting moves.
- Optionally show rapid moves as dashed lines.
- Mark the first XY position.
- Show a simple XY reference.
- Automatically fit the toolpath to the thumbnail.
- Display the XY extent.

## Deliberate limitations

This is **not a CNC simulator**.

It does not currently model:

- tool diameter
- material removal
- cutter depth
- 3D reliefs
- spindle state
- feed-rate timing
- work holding
- tool changes
- RapidChange macros

Those can be considered later if the basic preview proves useful.

## Test files

The prototype can load the project's existing practice files such as:

- `box.nc`
- `outline.nc`
- `vCarve.nc`

The live versions are in the project's GitHub `test-files` directory.

## Future integration

If the prototype works well, the parser and renderer can be moved into RC-ATC-4-Easel and used to create thumbnails in the operation list without changing the G-code-generation path.


## v0.1.1

Fixed local `file://` operation. The prototype no longer depends on JavaScript ES modules, which some browsers block when an HTML file is opened directly from the filesystem. The prototype can now be opened locally and should accept both the file picker and drag/drop.


## v0.1.3

- Rapid moves now render in medium gray.
- Rapid dash pattern changed from `4,4` to `6,8` for more separation.
- Show axes is now off by default.
- Display checkboxes now redraw loaded previews immediately without requiring the files to be reloaded.


## v0.1.3

- Start point is now a larger green dot.
- Added a red end-point dot.
- Added an independent “Mark end point” display checkbox.
- End point is derived from the final XY position encountered in the NC file.


## v0.1.4

- Fixed final XY tracking so the red end marker is rendered from the last XY move in the NC file.
- Start and end markers are now slightly smaller (6 px radius).
- Kept the green start marker and red end marker independently toggleable.


## v0.1.5

- Changed the green start marker to identify the first actual cutting move (`G1`, `G2`, or `G3`) rather than the first XY rapid move.
- This makes the marker represent the beginning of machining instead of the point where the machine begins positioning.


## v0.1.6

- Changed the red end marker to use the last actual cutting XY position (`G1`, `G2`, or `G3`).
- Rapid moves after the cut are no longer allowed to move the red marker.
- This keeps the endpoint on the machining path even when an NC file contains a later rapid return or parking move.
