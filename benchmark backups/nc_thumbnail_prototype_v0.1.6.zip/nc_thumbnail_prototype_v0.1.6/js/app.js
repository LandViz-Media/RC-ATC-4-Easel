// Responsibility: Browser UI for the standalone NC thumbnail prototype.
// This prototype is intentionally separate from the RC-ATC composer.

const fileInput=document.querySelector("#files");
const dropzone=document.querySelector("#dropzone");
const previews=document.querySelector("#previews");
const status=document.querySelector("#status");
const options={
  showRapid:document.querySelector("#showRapid"),
  showStart:document.querySelector("#showStart"),
  showEnd:document.querySelector("#showEnd"),
  showAxes:document.querySelector("#showAxes")
};

// Keep parsed files in memory so display options can redraw immediately.
const loadedPreviews = [];

async function addFiles(files){
  const list=[...files].filter(f=>/\.(nc|gcode|txt)$/i.test(f.name));
  if(!list.length){status.textContent="No supported .nc files selected.";return;}
  status.textContent=`Loaded ${list.length} file${list.length===1?"":"s"}.`;
  previews.innerHTML="";
  loadedPreviews.length=0;
  for(const file of list){
    const card=document.createElement("article");
    card.className="card";
    const h=document.createElement("h2"); h.textContent=file.name;
    const meta=document.createElement("div"); meta.className="meta";
    const canvas=document.createElement("canvas");
    canvas.setAttribute("aria-label",`Toolpath preview for ${file.name}`);
    const wrap=document.createElement("div"); wrap.className="canvas-wrap";
    wrap.append(canvas); card.append(h,meta,wrap); previews.append(card);
    try{
      const text=await file.text();
      const parsed=parseNC(text);
      loadedPreviews.push({canvas, parsed});
      if(!parsed.bounds){
        meta.textContent="No XY motion found.";
      }else{
        const b=parsed.bounds;
        meta.textContent=`XY extent: ${(b.maxX-b.minX).toFixed(3)} × ${(b.maxY-b.minY).toFixed(3)} in`;
      }
      redrawAll();
    }catch(err){
      meta.className="error"; meta.textContent=`Unable to parse: ${err.message}`;
    }
  }
}

fileInput.addEventListener("change",e=>addFiles(e.target.files));
function redrawAll(){
  for(const item of loadedPreviews){
    render(item.canvas,item.parsed,{
      showRapid:options.showRapid.checked,
      showStart:options.showStart.checked,
      showEnd:options.showEnd.checked,
      showAxes:options.showAxes.checked
    });
  }
}

for(const el of Object.values(options)){
  el.addEventListener("change", redrawAll);
}
dropzone.addEventListener("dragover",e=>{e.preventDefault();dropzone.classList.add("dragover");});
dropzone.addEventListener("dragleave",()=>dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop",e=>{e.preventDefault();dropzone.classList.remove("dragover");addFiles(e.dataTransfer.files);});

window.NCThumbnailPrototype = { parseNC, render };
